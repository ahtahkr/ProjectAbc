﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AustinsFirstProject.Git_Web_App.Areas.Home.Models
{
    public static class Utility
    {
        public static class Reference
        {
            public static class Tab
            {
                public enum Name : byte { HOME, HISTORY, COMMITTERS  }
            }
        }
    }
}
