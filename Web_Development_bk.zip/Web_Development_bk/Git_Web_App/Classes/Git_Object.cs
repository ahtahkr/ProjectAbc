﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AustinsFirstProject.Git_Web_App.Classes
{
    public class Git_Object
    {
        public string Git_Url_Name { get; set; }

        public string Git_Url { get; set; }
    }
}
