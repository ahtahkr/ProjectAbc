This is a git repo but not a submodule
