﻿namespace LibGit2Sharp
{
    /// <summary>
    /// Top-level certificate type. The usable certificates inherit from this class.
    /// </summary>
    public abstract class Certificate
    {
    }
}
