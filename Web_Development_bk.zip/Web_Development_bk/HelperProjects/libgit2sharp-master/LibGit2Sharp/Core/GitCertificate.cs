﻿using System.Runtime.InteropServices;

namespace LibGit2Sharp.Core
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct git_certificate
    {
        public GitCertificateType type;
    }
}
